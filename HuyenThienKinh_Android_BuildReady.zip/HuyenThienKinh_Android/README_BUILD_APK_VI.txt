TAO APK TU DONG – HUYEN THIEN KINH

Moi truong hien tai khong co Android SDK/Gradle va khong co ket noi mang de tai bo cong cu, nen chua the bien dich APK truc tiep tai day.
Du an da kem GitHub Actions de dich APK tu dong tren may chu GitHub.

CAC BUOC (co the lam tren dien thoai):
1. Dang nhap github.com va tao repository moi, dat ten HuyenThienKinh.
2. Chon Add file > Upload files.
3. Giai nen ZIP nay, tai len TOAN BO noi dung ben trong thu muc HuyenThienKinh_Android (bao gom thu muc an .github).
4. Commit changes len nhanh main.
5. Mo tab Actions > Build Huyen Thien Kinh APK. Neu workflow chua tu chay, chon Run workflow.
6. Cho den khi job co dau xanh, mo run do va keo xuong Artifacts.
7. Tai HuyenThienKinh-debug-apk.zip, giai nen de lay app-debug.apk.
8. Mo APK tren dien thoai de cai dat. Neu Android hoi cap quyen cai ung dung tu nguon nay, chi cho phep neu dung file vua tu repo cua minh tao ra.

APK debug dung de thu nghiem, khong phai ban phat hanh Play Store.

GHI CHU:
- Ung dung la vo Android WebView chay game HTML offline trong assets.
- Day chua phai game 3D native.
- Neu sua code, upload/commit lai; workflow se build lai.
