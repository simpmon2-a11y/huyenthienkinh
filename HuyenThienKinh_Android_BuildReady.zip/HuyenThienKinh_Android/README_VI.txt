HUYỀN THIÊN KÍNH – DỰ ÁN ANDROID
Phiên bản nền: 0.3.1

Đây là MÃ NGUỒN dự án Android Studio, chưa phải file APK đã biên dịch.

CÁCH TẠO APK:
1. Trên máy tính, cài Android Studio bản ổn định.
2. Giải nén thư mục HuyenThienKinh_Android.
3. Android Studio > Open > chọn thư mục HuyenThienKinh_Android.
4. Chờ Gradle Sync và cài Android SDK 35 nếu Android Studio yêu cầu.
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug nằm tại app/build/outputs/apk/debug/app-debug.apk.

ỨNG DỤNG dùng Android WebView để chạy game HTML offline trong assets.
JavaScript và DOM Storage được bật để hỗ trợ mô phỏng và lưu tiến trình.

LƯU Ý:
- Môi trường tạo tệp hiện tại không có Android SDK/Gradle nên chưa thể biên dịch APK tại đây.
- Bản này đóng gói giao diện web hiện có vào vỏ ứng dụng Android; chưa biến game thành đồ họa 3D native.
- Hãy kiểm thử trên thiết bị trước khi phát hành rộng rãi.
